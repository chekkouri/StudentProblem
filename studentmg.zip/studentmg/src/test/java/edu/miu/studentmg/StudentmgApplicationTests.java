package edu.miu.studentmg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmgApplicationTests {

	@Test
	void contextLoads() {
	}

}
