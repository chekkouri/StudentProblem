package edu.miu.studentmg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentmgApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentmgApplication.class, args);
	}

}
